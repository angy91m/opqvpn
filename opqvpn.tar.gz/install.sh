#!/bin/sh
SELF_PATH=$(dirname "$(realpath "$0")")
cp -r "$SELF_PATH/opqvpnd.d" /bin/opqvpnd.d
cp -r "$SELF_PATH/opqvpnd-console.d" /bin/opqvpnd-console.d
ln -s /bin/opqvpnd.d/opqvpnd /bin/opqvpnd
ln -s /bin/opqvpnd-console.d/opqvpnd-console /bin/opq-vpn